const jsonData = {
    option2: [
        {
            "Dokument": "Ulazni račun-tuzemni: 999-03/2023",
            "Ovjeru pokrenuo": "Ininov Administrator 1",
            "Ovjera u tijeku": "NE",
            "Odobreno": "DA",
            "Serijska": "DA",
            "Završetak": "08.11.2023."
        },
        {
            "Dokument": "Ulazni račun-tuzemni: 999-9/2023",
            "Ovjeru pokrenuo": "Ininov Administrator 1",
            "Ovjera u tijeku": "NE",
            "Odobreno": "DA",
            "Serijska": "DA",
            "Završetak": "06.11.2023."
        },
        {
            "Dokument": "Ulazni račun-tuzemni: 999-8/2023",
            "Ovjeru pokrenuo": "Ininov Administrator 1",
            "Ovjera u tijeku": "DA",
            "Odobreno": "NE",
            "Serijska": "DA",
            "Završetak": ""
        },
        {
            "Dokument": "Ulazni račun-tuzemni: 999-7/2023",
            "Ovjeru pokrenuo": "Ininov Administrator 1",
            "Ovjera u tijeku": "NE",
            "Odobreno": "DA",
            "Serijska": "DA",
            "Završetak": "06.11.2023."
        },
        {
            "Dokument": "Ulazni račun-tuzemni: 999-6/2023",
            "Ovjeru pokrenuo": "Ininov Administrator 1",
            "Ovjera u tijeku": "NE",
            "Odobreno": "DA",
            "Serijska": "DA",
            "Završetak": "06.11.2023."
        },
        {
            "Dokument": "Ulazni račun-tuzemni: 999-5/2023",
            "Ovjeru pokrenuo": "Ininov Administrator 1",
            "Ovjera u tijeku": "NE",
            "Odobreno": "DA",
            "Serijska": "DA",
            "Završetak": "06.11.2023."
        },
        {
            "Dokument": "Ulazni račun-tuzemni: 999-4/2023",
            "Ovjeru pokrenuo": "Ininov Administrator 1",
            "Ovjera u tijeku": "DA",
            "Odobreno": "NE",
            "Serijska": "DA",
            "Završetak": ""
        },
        {
            "Dokument": "Ulazni račun-tuzemni: 999-3/2023",
            "Ovjeru pokrenuo": "Ininov Administrator 1",
            "Ovjera u tijeku": "NE",
            "Odobreno": "DA",
            "Serijska": "DA",
            "Završetak": "06.11.2023."
        },
        {
            "Dokument": "Ulazni račun-tuzemni: 999-2/2023",
            "Ovjeru pokrenuo": "Ininov Administrator 1",
            "Ovjera u tijeku": "NE",
            "Odobreno": "DA",
            "Serijska": "DA",
            "Završetak": "06.11.2023."
        },
        {
            "Dokument": "Ulazni račun-tuzemni: 999-1/2023",
            "Ovjeru pokrenuo": "Ininov Administrator 1",
            "Ovjera u tijeku": "NE",
            "Odobreno": "DA",
            "Serijska": "DA",
            "Završetak": "06.11.2023."
        },
        {
            "Dokument": "Ulazni račun-tuzemni: 865-12-3/2023",
            "Ovjeru pokrenuo": "Ininov Administrator 1",
            "Ovjera u tijeku": "NE",
            "Odobreno": "DA",
            "Serijska": "DA",
            "Završetak": "06.11.2023."
        },
        {
            "Dokument": "Ulazni račun-tuzemni: 255-13/2023",
            "Ovjeru pokrenuo": "Ininov Administrator 1",
            "Ovjera u tijeku": "NE",
            "Odobreno": "DA",
            "Serijska": "DA",
            "Završetak": "03.11.2023."
        },
        {
            "Dokument": "Ulazni račun-tuzemni: 89-7/2023",
            "Ovjeru pokrenuo": "Ininov Administrator 1",
            "Ovjera u tijeku": "DA",
            "Odobreno": "NE",
            "Serijska": "DA",
            "Završetak": ""
        },
        {
            "Dokument": "Ulazni račun-tuzemni: 99-78/2023",
            "Ovjeru pokrenuo": "Ininov Administrator 1",
            "Ovjera u tijeku": "DA",
            "Odobreno": "NE",
            "Serijska": "DA",
            "Završetak": ""
        },
        {
            "Dokument": "Ulazni račun-tuzemni: 222-1/2023",
            "Ovjeru pokrenuo": "Ininov Administrator 1",
            "Ovjera u tijeku": "DA",
            "Odobreno": "NE",
            "Serijska": "DA",
            "Završetak": ""
        },
        {
            "Dokument": "Ulazni račun-tuzemni: 99-9/2023",
            "Ovjeru pokrenuo": "Ininov Administrator 1",
            "Ovjera u tijeku": "DA",
            "Odobreno": "NE",
            "Serijska": "DA",
            "Završetak": ""
        },
        {
            "Dokument": "Ulazni račun-tuzemni: 78-09/2023",
            "Ovjeru pokrenuo": "Ininov Administrator 1",
            "Ovjera u tijeku": "DA",
            "Odobreno": "NE",
            "Serijska": "DA",
            "Završetak": ""
        },
        {
            "Dokument": "Ulazni račun-tuzemni: 77-2/2023",
            "Ovjeru pokrenuo": "Ininov Administrator 1",
            "Ovjera u tijeku": "DA",
            "Odobreno": "NE",
            "Serijska": "DA",
            "Završetak": ""
        },
        {
            "Dokument": "Ulazni račun-tuzemni: 33-5/2023",
            "Ovjeru pokrenuo": "Ininov Administrator 1",
            "Ovjera u tijeku": "DA",
            "Odobreno": "NE",
            "Serijska": "DA",
            "Završetak": ""
        },
        {
            "Dokument": "Ulazni račun-tuzemni: 99-8/2023",
            "Ovjeru pokrenuo": "Ininov Administrator 1",
            "Ovjera u tijeku": "DA",
            "Odobreno": "NE",
            "Serijska": "DA",
            "Završetak": ""
        }
    ],
    option3: [
        {
            "Dokument": "Ulazni račun-tuzemni: 999-03/2023",
            "Ovjeru pokrenuo": "Ininov Administrator 1",
            "Ovjera u tijeku": "NE",
            "Odobreno": "DA",
            "Serijska": "DA",
            "Završetak": "08.11.2023."
        },
        {
            "Dokument": "Ulazni račun-tuzemni: 999-9/2023",
            "Ovjeru pokrenuo": "Ininov Administrator 1",
            "Ovjera u tijeku": "NE",
            "Odobreno": "DA",
            "Serijska": "DA",
            "Završetak": "06.11.2023."
        },
        {
            "Dokument": "Ulazni račun-tuzemni: 999-8/2023",
            "Ovjeru pokrenuo": "Ininov Administrator 1",
            "Ovjera u tijeku": "DA",
            "Odobreno": "NE",
            "Serijska": "DA",
            "Završetak": ""
        },
        {
            "Dokument": "Ulazni račun-tuzemni: 999-7/2023",
            "Ovjeru pokrenuo": "Ininov Administrator 1",
            "Ovjera u tijeku": "NE",
            "Odobreno": "DA",
            "Serijska": "DA",
            "Završetak": "06.11.2023."
        },
        {
            "Dokument": "Ulazni račun-tuzemni: 999-6/2023",
            "Ovjeru pokrenuo": "Ininov Administrator 1",
            "Ovjera u tijeku": "NE",
            "Odobreno": "DA",
            "Serijska": "DA",
            "Završetak": "06.11.2023."
        },
        {
            "Dokument": "Ulazni račun-tuzemni: 999-5/2023",
            "Ovjeru pokrenuo": "Ininov Administrator 1",
            "Ovjera u tijeku": "NE",
            "Odobreno": "DA",
            "Serijska": "DA",
            "Završetak": "06.11.2023."
        },
        {
            "Dokument": "Ulazni račun-tuzemni: 999-4/2023",
            "Ovjeru pokrenuo": "Ininov Administrator 1",
            "Ovjera u tijeku": "DA",
            "Odobreno": "NE",
            "Serijska": "DA",
            "Završetak": ""
        },
        {
            "Dokument": "Ulazni račun-tuzemni: 999-3/2023",
            "Ovjeru pokrenuo": "Ininov Administrator 1",
            "Ovjera u tijeku": "NE",
            "Odobreno": "DA",
            "Serijska": "DA",
            "Završetak": "06.11.2023."
        },
        {
            "Dokument": "Ulazni račun-tuzemni: 999-2/2023",
            "Ovjeru pokrenuo": "Ininov Administrator 1",
            "Ovjera u tijeku": "NE",
            "Odobreno": "DA",
            "Serijska": "DA",
            "Završetak": "06.11.2023."
        },
        {
            "Dokument": "Ulazni račun-tuzemni: 999-1/2023",
            "Ovjeru pokrenuo": "Ininov Administrator 1",
            "Ovjera u tijeku": "NE",
            "Odobreno": "DA",
            "Serijska": "DA",
            "Završetak": "06.11.2023."
        },
        {
            "Dokument": "Ulazni račun-tuzemni: 865-12-3/2023",
            "Ovjeru pokrenuo": "Ininov Administrator 1",
            "Ovjera u tijeku": "NE",
            "Odobreno": "DA",
            "Serijska": "DA",
            "Završetak": "06.11.2023."
        },
        {
            "Dokument": "Ulazni račun-tuzemni: 255-13/2023",
            "Ovjeru pokrenuo": "Ininov Administrator 1",
            "Ovjera u tijeku": "NE",
            "Odobreno": "DA",
            "Serijska": "DA",
            "Završetak": "03.11.2023."
        },
        {
            "Dokument": "Ulazni račun-tuzemni: 89-7/2023",
            "Ovjeru pokrenuo": "Ininov Administrator 1",
            "Ovjera u tijeku": "DA",
            "Odobreno": "NE",
            "Serijska": "DA",
            "Završetak": ""
        },
        {
            "Dokument": "Ulazni račun-tuzemni: 99-78/2023",
            "Ovjeru pokrenuo": "Ininov Administrator 1",
            "Ovjera u tijeku": "DA",
            "Odobreno": "NE",
            "Serijska": "DA",
            "Završetak": ""
        },
        {
            "Dokument": "Ulazni račun-tuzemni: 222-1/2023",
            "Ovjeru pokrenuo": "Ininov Administrator 1",
            "Ovjera u tijeku": "DA",
            "Odobreno": "NE",
            "Serijska": "DA",
            "Završetak": ""
        },
        {
            "Dokument": "Ulazni račun-tuzemni: 99-9/2023",
            "Ovjeru pokrenuo": "Ininov Administrator 1",
            "Ovjera u tijeku": "DA",
            "Odobreno": "NE",
            "Serijska": "DA",
            "Završetak": ""
        },
        {
            "Dokument": "Ulazni račun-tuzemni: 78-09/2023",
            "Ovjeru pokrenuo": "Ininov Administrator 1",
            "Ovjera u tijeku": "DA",
            "Odobreno": "NE",
            "Serijska": "DA",
            "Završetak": ""
        },
        {
            "Dokument": "Ulazni račun-tuzemni: 77-2/2023",
            "Ovjeru pokrenuo": "Ininov Administrator 1",
            "Ovjera u tijeku": "DA",
            "Odobreno": "NE",
            "Serijska": "DA",
            "Završetak": ""
        },
        {
            "Dokument": "Ulazni račun-tuzemni: 33-5/2023",
            "Ovjeru pokrenuo": "Ininov Administrator 1",
            "Ovjera u tijeku": "DA",
            "Odobreno": "NE",
            "Serijska": "DA",
            "Završetak": ""
        },
        {
            "Dokument": "Ulazni račun-tuzemni: 99-8/2023",
            "Ovjeru pokrenuo": "Ininov Administrator 1",
            "Ovjera u tijeku": "DA",
            "Odobreno": "NE",
            "Serijska": "DA",
            "Završetak": ""
        }
    ]
};

const displayArea = document.getElementById("data-display");

function handleSelection() {
    const selectedValue = document.getElementById("data-select").value;
    const data = jsonData[selectedValue];

    if (!selectedValue) {
        document.getElementById("sidebar").classList.remove("open");
        return;
    }

    renderData(selectedValue, data);
    document.getElementById("sidebar").classList.add("open");
}

function renderData(option, data) {
    displayArea.innerHTML = "";


    if (option === "option2") {
        // Render as table
        const table = document.createElement("table");
        const headerRow = document.createElement("tr");

        // Add table headers
        const headers = ["Dokument", "Ovjeru pokrenuo", "Ovjera u tijeku", "Odobreno", "Serijska", "Završetak"];
        headers.forEach(headerText => {
            const th = document.createElement("th");
            th.textContent = headerText;
            headerRow.appendChild(th);
        });
        table.appendChild(headerRow);

        // Add table rows
        data.forEach(item => {
            const row = document.createElement("tr");
            headers.forEach(key => {
                const td = document.createElement("td");
                td.textContent = item[key] || "";
                row.appendChild(td);
            });
            table.appendChild(row);
        });

        displayArea.appendChild(table);
    } else if (option === "option3") {
        // Render as cards
        const cardContainer = document.createElement("div");
        cardContainer.className = "card-container";

        data.forEach(item => {
            const card = document.createElement("div");
            card.className = "card";
            card.innerHTML = `
                        <h3>${item.Dokument}</h3>
                        <p><strong>Ovjeru pokrenuo:</strong> ${item["Ovjeru pokrenuo"]}</p>
                        <p><strong>Ovjera u tijeku:</strong> ${item["Ovjera u tijeku"]}</p>
                        <p><strong>Odobreno:</strong> ${item.Odobreno}</p>
                        <p><strong>Serijska:</strong> ${item.Serijska}</p>
                        <p><strong>Završetak:</strong> ${item.Završetak || ""}</p>
                    `;
            cardContainer.appendChild(card);
        });

        displayArea.appendChild(cardContainer);
    }
}