﻿var app = angular.module('ininapp', ['ui.router']);
app.config(['$stateProvider', '$urlRouterProvider', function ($stateProvider, $urlRouterProvider) {
    $urlRouterProvider.otherwise('/index');
    $stateProvider
        .state('index', {
            url: '/index',
            views: {
                'content': {
                    templateUrl: 'views/index.html'
                }
            }
        })
        .state('administracija-ovjera', {
            url: '/administracija-ovjera',
            views: {
                'content': {
                    templateUrl: 'views/administracija-ovjera.html'
                }
            }
        })
        .state('moje-ovjere', {
            url: '/moje-ovjere',
            views: {
                'content': {
                    templateUrl: 'views/moje-ovjere.html'
                }
            }
        })
    ;
}])