﻿app.controller('MojeOvjereCtrl', ['$scope', '$state', '$stateParams', function ($scope, $state, $stateParams) {
    var vm = this;
	
    vm.Title = "INDEX";

    function init(){
    }

    init();
}]);