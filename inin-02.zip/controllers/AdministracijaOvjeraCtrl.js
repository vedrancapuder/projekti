﻿app.controller('AdministracijaOvjeraCtrl', ['$scope', '$state', '$stateParams', function ($scope, $state, $stateParams) {
    var vm = this;

    vm.Items = [
        {
            title: "Ulazni račun-tuzemni: 999-03/2023",
            initiator: "Ininov Administartor 1",
            inProgress: false,
            approved: true,
            serial: true,
            completionDate: "08.11.2023."
        },
        {
            title: "Ulazni račun-tuzemni: 999-9/2023",
            initiator: "Ininov Administartor 1",
            inProgress: false,
            approved: true,
            serial: true,
            completionDate: "06.11.2023."
        },
        {
            title: "Ulazni račun-tuzemni: 999-8/2023",
            initiator: "Ininov Administartor 1",
            inProgress: true,
            approved: false,
            serial: true,
            completionDate: ""
        },
        {
            title: "Ulazni račun-tuzemni: 999-7/2023",
            initiator: "Ininov Administartor 1",
            inProgress: false,
            approved: true,
            serial: true,
            completionDate: "06.11.2023."
        },
        {
            title: "Ulazni račun-tuzemni: 999-6/2023",
            initiator: "Ininov Administartor 1",
            inProgress: false,
            approved: true,
            serial: true,
            completionDate: "06.11.2023."
        },
        {
            title: "Ulazni račun-tuzemni: 999-5/2023",
            initiator: "Ininov Administartor 1",
            inProgress: false,
            approved: true,
            serial: true,
            completionDate: "06.11.2023."
        },
        {
            title: "Ulazni račun-tuzemni: 999-4/2023",
            initiator: "Ininov Administartor 1",
            inProgress: true,
            approved: false,
            serial: true,
            completionDate: ""
        },
        {
            title: "Ulazni račun-tuzemni: 999-3/2023",
            initiator: "Ininov Administartor 1",
            inProgress: false,
            approved: true,
            serial: true,
            completionDate: "06.11.2023."
        },
        {
            title: "Ulazni račun-tuzemni: 999-2/2023",
            initiator: "Ininov Administartor 1",
            inProgress: false,
            approved: true,
            serial: true,
            completionDate: "06.11.2023."
        },
        {
            title: "Ulazni račun-tuzemni: 999-1/2023",
            initiator: "Ininov Administartor 1",
            inProgress: false,
            approved: true,
            serial: true,
            completionDate: "06.11.2023."
        },
        {
            title: "Ulazni račun-tuzemni: 865-12-3/2023",
            initiator: "Ininov Administartor 1",
            inProgress: false,
            approved: true,
            serial: true,
            completionDate: "06.11.2023."
        },
        {
            title: "Ulazni račun-tuzemni: 255-13/2023",
            initiator: "Ininov Administartor 1",
            inProgress: false,
            approved: true,
            serial: true,
            completionDate: "03.11.2023."
        },
        {
            title: "Ulazni račun-tuzemni: 89-7/2023",
            initiator: "Ininov Administartor 1",
            inProgress: true,
            approved: false,
            serial: true,
            completionDate: ""
        },
        {
            title: "Ulazni račun-tuzemni: 99-78/2023",
            initiator: "Ininov Administartor 1",
            inProgress: true,
            approved: false,
            serial: true,
            completionDate: ""
        },
        {
            title: "Ulazni račun-tuzemni: 222-1/2023",
            initiator: "Ininov Administartor 1",
            inProgress: true,
            approved: false,
            serial: true,
            completionDate: ""
        },
        {
            title: "Ulazni račun-tuzemni: 99-9/2023",
            initiator: "Ininov Administartor 1",
            inProgress: true,
            approved: false,
            serial: true,
            completionDate: ""
        },
        {
            title: "Ulazni račun-tuzemni: 78-09/2023",
            initiator: "Ininov Administartor 1",
            inProgress: true,
            approved: false,
            serial: true,
            completionDate: ""
        },
        {
            title: "Ulazni račun-tuzemni: 77-2/2023",
            initiator: "Ininov Administartor 1",
            inProgress: true,
            approved: false,
            serial: true,
            completionDate: ""
        },
        {
            title: "Ulazni račun-tuzemni: 33-5/2023",
            initiator: "Ininov Administartor 1",
            inProgress: true,
            approved: false,
            serial: true,
            completionDate: ""
        },
        {
            title: "Ulazni račun-tuzemni: 99-8/2023",
            initiator: "Ininov Administartor 1",
            inProgress: true,
            approved: false,
            serial: true,
            completionDate: ""
        },
    ];

    function init(){
    }

    init();
}]);